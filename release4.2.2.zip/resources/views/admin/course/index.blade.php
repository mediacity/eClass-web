@extends('admin.layouts.master')
@section('title','View Course')
@section('maincontent')
@include('admin.course.partial.index')
@endsection
